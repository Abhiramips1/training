package demo;
import java.util.Scanner;
public class Bank {
	private int Customer_Id;
	private String Customer_name;
	private int age;
	
	Scanner e= new Scanner(System.in);
//CREATE AN ACCOUNT
	void openAccount() {
        System.out.print("Enter Customer Id : ");
        Customer_Id = e.nextInt();
        System.out.print("Enter Name: ");
        Customer_name = e.nextLine();
        System.out.print("Enter Age: ");
        age = e.nextInt();

}
}