package demo;

 class student {
	 int id;  
	 String name;  
	 //method to display the value of id and name  
	 void display(){System.out.println(id+" "+name);}  
	   

	public static void main(String[] args) {
		//creating objects  
		student s1=new student();  
		student s2=new student();  
		//displaying values of the object  
		s1.id=101;
		s1.name="ram";
		s2.id=102;
		s2.name="Dev";
;		s1.display();  
		s2.display();  
		}  
	}


