package demo;
import java.util.Scanner;

public class calculator {

	public static void main(String[] args) {
		int sum,dif,pro;
		double  q;
		for(int i=1;i==1;)  {
		
		Scanner e = new Scanner(System.in);
		System.out.println("enter the case:");
		int ms =e.nextInt();
		System.out.println("enter the first number:");
		int a=e.nextInt();
		System.out.println("enter the second number:");
		int b = e. nextInt();
		
		switch (ms) 
		
		
		{
		case 1:
			sum = a+b;
			System.out.println("sum of numbers :"+sum);
			break;
		case 2:
		dif =a-b;
		System.out.println("difference of numbers :"+dif);
		break;
		case 3:
			pro = a*b;
			System.out.println("product of two numbers :"+pro);
			break;

		
		case 4:
			q= a/b ;
			System.out.println("qoutient of numbers :"+q);
			break;
		case 6:
			i=0;
			System.out.println(".......................Exit....................");
		default:
			System.out.println("error .....try another case");
			break;
			}
		
		}
	}	
	}


