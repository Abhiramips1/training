package demo;

public class encap {

	public static void main(String[] args) {
		
	}

}
 class student
 {
	private int rollno;
	private String Name;
	
	public String setname(String name)
	{
	return name="newname";
	}
	public int setrollno(int r)
	{
		return rollno=r;
		
	}
	public g(){
	 {
		 
	 }
 }