package demo;


public class mainMethod {

	public static void main(String[] args) {
		person t1 = new person();
		t1 .name="sumi";
		t1.id= 1789;
		t1.showAddress();
	
	}		
}
