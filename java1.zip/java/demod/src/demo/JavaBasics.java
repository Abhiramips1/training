package demo;

public class JavaBasics {

	public static void main(String[] args) {
		int a=10 ;
		int b = 20 ;
		
		//logical and &&
		//System.out.println(a>5&&b>10); //true
		//System.out.println(a<5&&b>10);  // false
		
		
		//logical or|| ( any one should be true)
		
		//System.out.println(a>5||b<10); //true
		
		//logical not !
		//System.out.println(!(a<5));//true
		
		// ++ operator
		//System.out.println(a++); 
		//System.out.println(++a);
		
		// <<
		System.out.println(a<<b);
		
		
		
	}
}
