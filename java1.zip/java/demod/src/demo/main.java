package demo;
import java.io.File;
import java.io.FileReader;

public class main {

	public static void main(String[] args) {
		File f = new File("sample.txt");
		try {
		FileReader fr = new FileReader("sample.txt");
		char [] data = new char[50];
		fr.read(data);
		System.out.println(data);
		fr.close();
		}
		catch(Exception e) {
			System.out.println("error");
		}
		
		
}
}


