package demo;

public class person {
	String name;
	int id ;
	 public void showAddress() 
	 {
		 System.out.println("Name : "+name);
		 System.out.println("id  :"+id);
	 }
	 class Teacher extends person
	 {
		 
	 }
class student extends person
{
	
}
class staff extends person 
{
	
}
}
