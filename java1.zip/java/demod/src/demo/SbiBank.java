package demo;
import java.util.Scanner;

public class SbiBank {

	public static void main(String[] args) {
		Scanner e = new Scanner(System.in);
		System.out.println("           WELCOME TO SBI \n");
		System.out.println(".....................................");
		System.out.println(".....................................\n");
        System.out.println ("DO you have an account:");
        
        String a = e.nextLine();
        if (a.equals("yes")) {
            System.out.println ("You arent dumb, nice.");
        } // end of if
        else {
            System.out.println ("  Do you want to create an account");
            {
            	String b=e.nextLine();
            	if (b.equals(("yes")))
            			{
            		
            	}
            }
        } // end of if-else
    }

	}


//Bank acc=new Bank();
//acc.openAccount;