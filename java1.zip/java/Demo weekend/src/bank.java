import java.util.Scanner;
public class bank {
	int customer_no ;
	String customer_name;
	int customer_age;
	int account_no;
	float amt,a;
	Scanner e= new Scanner(System.in);
	
	// create account
	void createaccount()
	{
	System.out.println("Enter the customer Id:");
	customer_no=e.nextInt();
	System.out.println("Enter the customer name :");
	customer_name=e.nextLine();
	System.out.println("Enter the age:");
	customer_age=e.nextInt();
		
	
}
	// show details
	void details() {
		System.out.println("Enter the account number:");
		account_no=e.nextInt();
		System.out.println("Enter the customer Id:");
		customer_no=e.nextInt();
		System.out.println("Enter the customer name :");
		customer_name=e.nextLine();
		System.out.println("Enter the amount:");
		amt=e.nextFloat();
	}
	void show() {
		System.out.println("account number:" +account_no +"   "+"Name:"+customer_name +"   "+"Amount:"+amt);
		
}

	void Deposite() {
		
		amt+=a;
		System.out.println("Deposite amount:"+a);
	}
	void withdraw(float w)	{
		if(amt<w) {
			System.out.println("INSUFFICIENT BALANCE");
		}else
			amt-=w;
		System.out.println("withdraw amt : "+w);
	}
	void balanceCheck() {
		System.out.println("Balance amount;"+amt);
	
}
}