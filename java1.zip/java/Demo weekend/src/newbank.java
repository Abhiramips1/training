import java.util.Scanner;
public class bank {
	int customer_no ;
	String customer_name;
	int customer_age;
	int account_no;
	float amt,a;
	Scanner e= new Scanner(System.in);
	
	// create account
	 public void createaccount()
	{
	System.out.println("Enter the customer Id:");
	customer_no=e.nextInt();
	System.out.println("Enter the customer name :");
	customer_name=e.nextLine();
	System.out.println("Enter the age:");
	customer_age=e.nextInt();
public class newbank {

	public static void main(String[] args) {
		Scanner KB=new Scanner (System.in);
		System.out.println("           WELCOME TO SBI \n");
		System.out.println(".....................................");
		System.out.println(".....................................\n");
		
		 System.out.print("How Many Customer U Want to Input : ");
	        int n = KB.nextInt();
	        Bank C[] = new Bank[n];
	        for (int i = 0; i < C.length; i++) {
	            C[i] = new Bank();
	            C[i].createaccount();
	        }
	}

}
