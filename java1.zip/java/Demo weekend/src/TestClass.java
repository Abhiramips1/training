import java.util.Scanner;
public class TestClass {

	public static void main(String[] args) {
		
		Scanner t =new Scanner(System.in);
		int ch;
		System.out.println("           WELCOME TO SBI \n");
		System.out.println(".....................................");
		System.out.println(".....................................\n");
		 {
			 
			 bank b=new bank();
	        System.out.println("Main Menu\n1. Create Account\n2.Provide account details\n3. Show details\n4. Deposite\n5 .Withdrawal\n6. Balance ");
	            System.out.println("Ur Choice :"); ch = t.nextInt();
	            switch (ch) {
	            case 1:
	            	b.createaccount();
	            	break;
	            case 2:
	            	b.details();
	            	break;
	            case 3:
	            	b.show();
	            	break;
	            case 4:
	            	b.Deposite();
	            	break;
	            case 5:
	            	b.withdraw(1000);
	            	break;
	            case 6:
	            	b.balanceCheck();
	            	break;
	            	
	           default:
	        	   System.out.println("ernter valid input");
	            		
	            	
	            }
	}

}
}
