package com.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		Configuration config=new Configuration();
		config.configure("application-cfg.xml");
		SessionFactory factory=config.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Employee emp=new Employee();
		emp.setEmpId(101);
		emp.setEmpName("Abhirami");
		emp.setSalary(1200.78);
		session.persist(emp);
		tx.commit();
		System.out.println("data added...");
		session.close();
		
	}

}
