import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public name="Abhi";
 public str="";
 public count=0;
 public over =0;
 public evenorodd="Even";
 public coun=0;
 

fruit=[
  { "name":"Apple" ,"price":100},
{ "name":"Graps" ,"price":200},
{ "name":"Watermelon" ,"price":150},
{ "name":"Orange" ,"price":120}
];

// characters: Character[] = [
//   {
//   actor_name: 'Peter Dinklage',
//   character_name: 'Tyrion Lannister',
//   gender: 'Male',
//       status: 'Alive'
//   },
//   {
//   actor_name: 'Sean Bean',
//   character_name: 'Ned Stark',
//   gender: 'Male',
//   status: 'Dead'
//   },
//   {
//   actor_name: 'Emilia Clark',
//   character_name: 'Khaleesi',
//   gender: 'Female',
//   status: 'Alive'
//   },
//   {
//   actor_name: 'Catelyn Stark',
//   character_name: 'Michelle Fairley',
//   gender: 'Female',
//   status: 'Dead'
//   }
// ];



  title = 'angularpro';
  // data={
  // sec:"FSD"
  // }
  // color(){
  //   return "green";
  // }
gfunction(){
  this.str="good morning";
}
afterfun(){
  this.str="good afternoon";
}
infun(){
  this.count=this.count+1
  if(this.count%2==0){
    this.evenorodd="Even";
  }else{
    this.evenorodd="odd";
  }
}
defun(){
  this.count=this.count-1
  if(this.count%2==0){
    this.evenorodd="Even";
  }else{
    this.evenorodd="odd";
  }
}


  
}
