module project {
	exports project;
}