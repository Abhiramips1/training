package proj1;

public class Area {
	public int area(int a,int b){
        return (a*b);
	}
}
