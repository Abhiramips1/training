package proj1;

public class subtraction {
	public int sub(int a,int b){
        return (a-b);
  }

}
