package proj1;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class demo {

	public static void main(String[] args) {
		Result result =JUnitCore.runClasses(junit1.class);
		for (Failure failure : result.getFailures());
		{
			System.out.println(Failure.toString());
			System.out.println("Result=="+result.wasSuccessful());
		}
	}

}
