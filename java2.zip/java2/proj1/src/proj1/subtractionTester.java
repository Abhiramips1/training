package proj1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class subtractionTester {
	private subtraction subtraction;

	/** * Initialization */
	@Before
	public void setUp() {
		subtraction = new subtraction();
	}

	/** * Test case for add method */
	@Test
	public void test1() {
		int i = subtraction.sub(10, 7);
		assertEquals(3, i);
	}

	/** * destroy the object */
	@After
	public void tearDown() {
		subtraction = null;
	}

	

}
