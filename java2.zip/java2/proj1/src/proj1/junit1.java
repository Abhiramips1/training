package proj1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class junit1 {
@Test
public void setup()
{
	String str="one";
	assertEquals("one",str);
	
}
}
