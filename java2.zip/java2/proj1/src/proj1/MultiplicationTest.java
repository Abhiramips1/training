package proj1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MultiplicationTest {
	private Multiplication multi;

	/** * Initialization */
	@Before
	public void setUp() {
		multi = new Multiplication();
	}

	/** * Test case for add method */
	@Test
	public void test() {
		int i = multi.mul(2, 7);
		assertEquals(14, i);
	}

	/** * destroy the object */
	@After
	public void tearDown() {
		multi = null;
	}

	
	

}
