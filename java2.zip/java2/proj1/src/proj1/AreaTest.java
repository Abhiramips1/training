package proj1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AreaTest {
	private Area a;

	/** * Initialization */
	@Before
	public void setUp() {
		a = new Area();
	}

	/** * Test case for add method */
	@Test
	public void test() {
		int i = a.area(2, 2);
		assertEquals(4, i);
	}

	/** * destroy the object */
	@After
	public void tearDown() {
		a = null;
	}


	

}
