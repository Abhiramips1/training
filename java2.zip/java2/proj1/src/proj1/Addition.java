package proj1;

public class Addition {
	public int add(int a,int b){
        return (a+b);
  }
}

	