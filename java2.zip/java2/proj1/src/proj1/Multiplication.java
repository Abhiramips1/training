package proj1;

public class Multiplication {
	public int mul(int a,int b){
        return (a*b);
	}
}
