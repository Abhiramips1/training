package junitHome;

public class jumit {
	@Test
	public void setup()
	{
		String str="one";
		assertEquals()
	}
	
	

}
