package JDBC;
import java.sql.*;

public class Jdbc {

	public static void main(String[] args) {
		String URL = "jdbc:mysql://localhost:3306/demo3";
		String USER = "root";
		String PASS = "root";
		try {
		Connection conn = DriverManager.getConnection(URL, USER, PASS);
				Statement stmt = conn.createStatement();
				ResultSet rs=stmt.executeQuery("SELECT * FROM demo3.student;");
				while(rs.next())
					System.out.println(rs.getInt(1 +"  "+rs.getString(2)));
				stmt.close();
				conn.close();
					
		          
		      } catch (SQLException e) {
		         e.printStackTrace();
		      } 
		   }
				
				

	}


