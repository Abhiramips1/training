package newproj1;
import java.sql.*;
public class DemoClass {

	public static void main(String[] args) {
		String url ="jdbc:mysql://localhost:3306/University";
		String uname ="root";
		String pass = "root";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con =DriverManager.getConnection(url ,uname,pass);
			Statement st =con.createStatement();
			ResultSet rs =st.executeQuery("SELECT * FROM university.engineeringstudents; ");
			while(rs.next())
				System.out.println(rs.getInt(1)+ " "+ rs.getString(2)+ "  " + rs.getString(3)+  "  "+ rs.getString(4)+ "  "+rs.getInt(5)+ " "+rs.getInt(6));
				
			st.close();
			con.close();
			
		}
		catch(Exception e) {
			System.out.println(e);
			
		}
		
	}

}
