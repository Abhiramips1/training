package newproj1;
import java.sql.*;
public class Demo1 {

	public static void main(String[] args) 
	{
		 String URL = "jdbc:mysql://localhost/";
		  String USER = "root";
		  String PASS = "root";

		 
		      // Open a connection
		      try(Connection conn = DriverManager.getConnection(URL, USER, PASS);
		         Statement stmt = conn.createStatement();
		      ) {		      
		         String sql = "create database school";
		         stmt.executeUpdate(sql);
		         System.out.println("Database created successfully..."); 
		         
		         
		      } catch (Exception e) {
		         System.out.println(e);;
		}
	}
}

