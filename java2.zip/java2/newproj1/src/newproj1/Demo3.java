package newproj1;
import java.sql.*;
public class Demo3 {

	public static void main(String[] args) {
		String URL = "jdbc:mysql://localhost:3306/school";
		  String USER = "root";
		  String PASS = "root";
try {
		  Connection con =DriverManager.getConnection(URL ,USER,PASS);
			Statement st =con.createStatement();
		 String sql= "INSERT INTO student VALUES (100,'RAM')";
		 st.executeUpdate(sql);
		 
		  sql= "INSERT INTO student VALUES (101,'SONU')";
		 st.executeUpdate(sql);
		 
		  sql= "INSERT INTO student VALUES (102,'SETHU')";
		 st.executeUpdate(sql);
		 
		 
		 sql= "INSERT INTO student VALUES (103,'JEVAN')";
		 st.executeUpdate(sql);
		 
		 System.out.println("Inserted records into the table...");  
		 
		 st.close();
		 con.close();
} catch (Exception e)
{
		System.out.println(e); 
	}

	}
}
