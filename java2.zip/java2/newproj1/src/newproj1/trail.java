package newproj1;
import java.sql.*;
public class trail {

	public static void main(String[] args) {
		String url ="jdbc:mysql://localhost:3306/projectdb";
		String uname ="root";
		String pass = "root";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con =DriverManager.getConnection(url ,uname,pass);
			Statement st =con.createStatement();
			ResultSet rs =st.executeQuery("SELECT * FROM projectdb.payments; ");
			while(rs.next())
			System.out.println(rs.getInt(1)+  "  "+rs.getNString(2)+ " " +rs.getDate(3)+ " "+rs.getDouble(4));
			st.close();
			con.close();
			
		}
		catch(Exception e) {
			System.out.println(e);
			
		}
		
	}
	}


