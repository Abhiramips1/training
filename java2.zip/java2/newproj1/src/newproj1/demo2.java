package newproj1;
import java.sql.*;
public class demo2 {

	public static void main(String[] args) {
		String URL = "jdbc:mysql://localhost:3306/school";
		  String USER = "root";
		  String PASS = "root";

		 
		      // Open a connection
		      try(Connection conn = DriverManager.getConnection(URL, USER, PASS);
		         Statement stmt = conn.createStatement();
		      ) {	
		    	 // String sql1="CREATE TABLE student "+
		     // ("Id INTEGER  not NULL"+
		    	  //"stu_name VARCHAR(45) not NULL" +
		    		  //"PRIMARY KEY (Id)");
		    		  
		    	  
		    	  
		    	  
		    	  
		    	//  String sql="CREATE TABLE student" +
		    		//	  ("id INT NOT NULL " +
		    		//"stu_name VARCHAR(45) NOT NULL" +
		    		// "PRIMARY KEY (`id`)");
		    			 
		    	  String sql ="CREATE TABLE student " +
		    			  "(id INTEGER not NULL, " +
		    			  " name VARCHAR(45) not NULL, " + 
		    			  " PRIMARY KEY ( id ))"; 
		    		  
		    		  
			         stmt.executeUpdate(sql);
			         System.out.println("table created");
			         
			      } catch (Exception e) {
			         System.out.println(e);;
			}
		      }
	}


