package weekendpro;
import java.util.Scanner;

class Bank {
    private String accno;
    private String name;
    private long balance;
    int customer_no ;
	String customer_name;
	int customer_age;
	int account_no;

    Scanner e = new Scanner(System.in);

    //method to open an account
    void createaccount()
	{
	System.out.println("Enter the customer Id:");
	customer_no=e.nextInt();
	System.out.println("Enter the customer name :");
	customer_name=e.nextLine();
	System.out.println("Enter the age:");
	customer_age=e.nextInt();
		
    }

    //method to display account details
    void showAccount() {
        System.out.println(accno + "," + name + "," + balance);
    }

    //method to deposit money
    void deposit() {
        long amt;
        System.out.println("Enter Amount U Want to Deposit : ");
        amt = e.nextLong();
        balance = balance + amt;
    }

    //method to withdraw money
    void withdrawal() {
        long amt;
        System.out.println("Enter Amount U Want to withdraw : ");
        amt = e.nextLong();
        if (balance >= amt) {
            balance = balance - amt;
        } else {
            System.out.println("Less Balance..Transaction Failed..");
        }
    }

    //method to search an account number
    boolean search(String acn) {
        if (accno.equals(acn)) {
            showAccount();
            return (true);
        }
        return (false);
    }
}





public class SbiBank {

public static void main(String[] args) {
	Scanner e = new Scanner(System.in);

    //create initial accounts
	System.out.println("           WELCOME TO SBI \n");
	System.out.println(".....................................");
	System.out.println(".....................................\n");
   // System.out.println ("DO you have an account:");
    //String a = e.nextLine();
  //  if (a.equals("yes")) {
        //System.out.println ("You arent dumb, nice.");
   // } // end of if
   // else {
       // System.out.println ("  Do you want to create an account");
      //  {
        	//String b=e.nextLine();
        	//if (b.equals(("yes")))
        			//{
        		
        	//}
       // }
   // } // end of if-else
   
    int n = e.nextInt();
    Bank C[] = new Bank[n];
    for (int i = 0; i < C.length; i++) {
        C[i] = new Bank();
        C[i].createaccount();
    }

    //run loop until menu 5 is not pressed
    int ch;
    do {
        System.out.println("Main Menu\n1. Display All\n 2. Search By Account\n 3. Deposit\n 4. Withdrawal\n 5.E xit ");
            System.out.println("Ur Choice :"); ch = e.nextInt();
            switch (ch) {
                case 1:
                    for (int i = 0; i < C.length; i++) {
                        C[i].showAccount();
                    }
                    break;

                case 2:
                    System.out.print("Enter Account No U Want to Search...: ");
                    String acn = e.next();
                    boolean found = false;
                    for (int i = 0; i < C.length; i++) {
                        found = C[i].search(acn);
                        if (found) {
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Search Failed..Account Not Exist..");
                    }
                    break;

                case 3:
                    System.out.print("Enter Account No : ");
                    acn = e.next();
                    found = false;
                    for (int i = 0; i < C.length; i++) {
                        found = C[i].search(acn);
                        if (found) {
                            C[i].deposit();
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Search Failed..Account Not Exist..");
                    }
                    break;

                case 4:
                    System.out.print("Enter Account No : ");
                    acn = e.next();
                    found = false;
                    for (int i = 0; i < C.length; i++) {
                        found = C[i].search(acn);
                        if (found) {
                            C[i].withdrawal();
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Search Failed..Account Not Exist..");
                    }
                    break;

                case 5:
                    System.out.println("Good Bye..");
                    break;
            }
        }
        while (ch != 5);
}
	
}
		 

