package thurs29;
import java.util.Stack;
public class StackDemo {

	public static void main(String[] args) {
		Stack tower=new Stack();
		tower.add("red");
		tower.add("blue");
		tower.add("yellow");
		System.out.println(tower.peek());
		System.out.println(tower.get(1));
		
		
	}

}
