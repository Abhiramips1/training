package com.app;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
public class CollectionToArray {

	public static void main(String[] args) {
		List<Integer>list=List.of(1,2,3,4,5);
		Integer[]arrIntegers=list.toArray(Integer[]::new);
		System.out.println(Arrays.toString(arrIntegers));
		Set<Integer>hSet=new LinkedHashSet<>(list);
		hSet.remove(1);
		Integer[] array2 =list.toArray(Integer[]::new);
		Set<Country> hSetCountries=new HashSet<>();
		hSetCountries.add(new Country("IN",  "India"));
		hSetCountries.add(new Country("ID",  "Indonesia"));
		hSetCountries.add(new Country("SG",  "Singapore"));
		Country[] array3=hSetCountries.toArray(Country[]::new);
		System.out.println(Arrays.toString(array3));
		
		
	
	}

}
