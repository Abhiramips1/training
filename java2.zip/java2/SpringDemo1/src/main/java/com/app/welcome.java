package com.app;

public class welcome {
	private String name;
	
	
	
	public String  getName() {
		return name;
	}
	
public void setName(String name) {
	this.name = name;
}
public void printName() {
	System.out.println("Welcome to spring:"+name);
}
}
