package com.app.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.mapping.List;

public class StudentTest {

	public static void main(String[] args) {
		Configuration config=new Configuration();
		config.configure("application-cfg.xml");
		SessionFactory factory=config.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		//List<Student> list=new ArrayList<Student>();
		student st=new student();
		st.setStudentId(102);
		st.setName("reema");
		st.setAddress("Mumbai");
		session.save(st);
		tx.commit();
		System.out.println("Data Stored Successfully...!");

	}

}
