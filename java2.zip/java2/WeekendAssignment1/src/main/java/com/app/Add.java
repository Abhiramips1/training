package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Add
 */
@WebServlet("/Add")
public class Add extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	PreparedStatement ps;
    public Add() throws ClassNotFoundException, SQLException {
		super(); {
			Class.forName("com.mysql.jdbc.Driver");// loading the driver		
			Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/products","root","root");// Connection:Interface
		}
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String code = request.getParameter("pcode");
		String name = request.getParameter("pname");
		String quantity=request.getParameter("pq");
		String price=request.getParameter("price");

		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out =response.getWriter();
		try
		{
			ps=con.prepareStatement("insert into pdts values(?,?,?,?)");
			ps.setString(1,code);
			ps.setString(2, name);
			ps.setString(3, quantity);
			ps.setString(4, price);

			int i=ps.executeUpdate();
			if(i!=0) {
				out.print("Product are added successfully!!!!!");
				response.sendRedirect("home.jsp");
			}else {
				response.sendRedirect("error.jsp");
				ps.close();
				con.close();

			}
		} catch (SQLException e) {
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
