package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Delete1
 */
@WebServlet("/Delete1")
public class Delete1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
	PrintWriter out;
    public Delete1()  throws ClassNotFoundException, SQLException {
		super(); {
        // TODO Auto-generated constructor stub
			Class.forName("com.mysql.jdbc.Driver");// loading the driver		
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/products","root","root");// Connection:Interface
    }
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		out =response.getWriter();
		String id=request.getParameter("id");
		System.out.println(id);
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
			ps=con.prepareStatement("Delete FROM pdts where p_code=?");

			ps.setString(1,id);
			int i=ps.executeUpdate();
			response.getWriter().append("Served at: ").append(request.getContextPath());
			out =response.getWriter();
			System.out.println(i);
			if(i!=0) {
				out.print("Successfully deleted the product");
			}else {
				response.sendRedirect("error.jsp");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
