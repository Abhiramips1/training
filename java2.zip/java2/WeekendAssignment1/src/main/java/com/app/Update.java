package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out =response.getWriter();


		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM pdts");


			HttpSession session=request.getSession();
			session.setAttribute("resultset",rs);
			out.print("<html><body>");
			out.print("<h1>Welcome to Product Cart</h1>");
			out.print("<h2>See Your Products</h2>");
			if(!rs.isBeforeFirst()) // 

			{
				out.print("Sorry , No Products are avaliable ");
			}
			else {
				while (rs.next()) {
					// Retrieve by column name
					String id=rs.getString(1);
					out.println("<b>Product Code : </b>"+rs.getString(1));
					out.print("<br></br>");
					out.println("<b>Product Name : </b>"+rs.getString(2));
					out.print("<br></br>");
					out.println("<b>Product Price : </b>"+rs.getInt(3));
					out.print("<br></br>");
					out.println("<b>Product Quantity : </b>"+rs.getInt(4));
					out.print("<br></br>");
					out.print("<br></br>");
					//out.println("<input type=submit value=Delete onclick="+del+"("+id+")/>");
					out.println("<input type=submit value=Update onclick=super.del("+id+")+/");
					out.print("<br></br>");
					out.println("________________________________________________");
					out.print("<br></br>");
				}
			}
					out.print("</table>");
			out.print("</body></html> ");

			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Extract data from result set
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
