package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Delete
 */
@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
	PrintWriter out;
    public Delete() throws ClassNotFoundException, SQLException {
		super(); {
        // TODO Auto-generated constructor stub
			Class.forName("com.mysql.jdbc.Driver");// loading the driver		
			Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/products","root","root");// Connection:Interface
		}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		out =response.getWriter();


		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM pdts");


			HttpSession session=request.getSession();
			session.setAttribute("resultset",rs);
			response.sendRedirect("delete.jsp");
			//			out.print("<html><body>");
			//			out.print("<h1>Welcome to Product Cart</h1>");
			//			out.print("<h2>See Your Products</h2>");


			//			out.print("<table>");
			//			out.print("<tr>");

			//			out.print(" <th>Product Code</th>");
			//			out.print(" <th>Product Name</th>");
			//			out.print(" <th>Product Price</th>");
			//			out.print(" <th>Product Quantity</th>");

			//			out.print("</tr>");
			//			if(!rs.isBeforeFirst()) // 
			//
			//			{
			//				out.print("Sorry , No Products are avaliable ");
			//			}
			//			else {
			//				while (rs.next()) {
			//					// Retrieve by column name
			//					String id=rs.getString(1);
			//					out.println("<b>Product Code : </b>"+rs.getString(1));
			//					out.print("<br></br>");
			//					out.println("<b>Product Name : </b>"+rs.getString(2));
			//					out.print("<br></br>");
			//					out.println("<b>Product Price : </b>"+rs.getInt(3));
			//					out.print("<br></br>");
			//					out.println("<b>Product Quantity : </b>"+rs.getInt(4));
			//					out.print("<br></br>");
			//					out.print("<br></br>");
			//					//out.println("<input type=submit value=Delete onclick="+del+"("+id+")/>");
			//					out.println("<input type=submit name=del value=Delete onclick=doDelete(':"+id+"')+/");
			//					out.print("<br></br>");
			//					out.println("________________________________________________");
			//					out.print("<br></br>");

			//				out.print("<tr>");
			//
			//				out.print(" <th>"+rs.getString(1)+"</th>");
			//				out.print(" <th>"+rs.getString(2)+"</th>");
			//				out.print(" <th>"+rs.getInt(3)+"</th>");
			//				out.print(" <th>"+rs.getInt(4)+"</th>");
			//
			//				out.print("</tr>");




			//			out.print("</table>");
			//out.print("</body></html> ");



		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
