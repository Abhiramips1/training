package com.app;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.app.model.Student;

public class StudentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Configuration config=new Configuration();
config.configure("application-cfg.xml");
SessionFactory factory=config.buildSessionFactory();
Session session=factory.openSession();
Transaction tx=session.beginTransaction();
List<Student> list=new ArrayList<Student>();
Student st=new Student();
st.setStudId(102);
st.setName("Priya Kolhe");
st.setAddress("Mumbai");
session.save(st);
tx.commit();
System.out.println("Data Stored Successfully...!");
	}

}
