package weekend;

public class Bank {
	
	String Customer_name;
	int age;

	
	
	
	}

