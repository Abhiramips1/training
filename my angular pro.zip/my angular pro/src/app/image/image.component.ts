import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {
  image:string="../../assets/amazon.png";
  imgname:string="Amazon";

  constructor() { }
  

  ngOnInit(): void {
  }

  toggle(){

    if(this.image=="../../assets/amazon.png"){
      this.image="../../assets/flipkart.png";
      this.imgname="Flipkark";
    }
    else{
      this.image="./../assets/amazon.png";
      this.imgname="Amazon";
    }
  }

}
