import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rtf',
  templateUrl: './rtf.component.html',
  styleUrls: ['./rtf.component.css']
})
export class RTFComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
