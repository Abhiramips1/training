import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RTFComponent } from './rtf.component';

describe('RTFComponent', () => {
  let component: RTFComponent;
  let fixture: ComponentFixture<RTFComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RTFComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RTFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
