import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-mat',
  templateUrl: './angular-mat.component.html',
  styleUrls: ['./angular-mat.component.css']
})
export class AngularMatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
