import { Component, OnInit } from '@angular/core';
import { CloneVisitor } from '@angular/compiler/src/i18n/i18n_ast';
import { Router } from '@angular/router';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
  isCond:boolean=false;
  cars:string[]=["TATA","BMW","NANO","MARUTI"];
  mycar:string="TATA";
  myStyle={
color:"blue",
fontSize:"30px",
backgroundColor:"pink",
  }

employee=[
  { id:101, name :"Rahul", post:"HR",salary:85000, gender:"male"},
  { id:102, name :"Dev", post:"FSD",salary:85000, gender:"male"},
  { id:103, name :"Anu", post:"Developer",salary:85000, gender:"female"},
  { id:104, name :"Neenu", post:"HR",salary:86000, gender:"female"},
]

  

  constructor(private _router:Router) { }

  ngOnInit(): void {
  }
  setParameter(val:any){
    this._router.navigate(['/directives',val]);
  }

}
