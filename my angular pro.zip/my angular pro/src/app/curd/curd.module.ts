import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CurdRoutingModule } from './curd-routing.module';
import { AddComponent } from './add/add.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EditComponent } from './edit/edit.component';


@NgModule({
  declarations: [
    AddComponent,
    DashboardComponent,
    EditComponent
  ],
  imports: [
    CommonModule,
    CurdRoutingModule
  ]
})
export class CurdModule { }
