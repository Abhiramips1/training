import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DatabindingComponent } from './databinding/databinding.component';
import{FormsModule}from'@angular/forms';
  import { from } from 'rxjs';
import { ImageComponent } from './image/image.component';
import { DirectivesComponent } from './directives/directives.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { AngularFormComponent } from './angular-form/angular-form.component';
import { UTDFComponent } from './utdf/utdf.component';
import { RTFComponent } from './rtf/rtf.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PipeComponent } from './pipe/pipe.component';
import { MygenderPipe } from './shared/customed/mygender.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMatComponent } from './angular-mat/angular-mat.component';
import {MaterialModule} from './material/material.module';


@NgModule({
  declarations: [
    AppComponent,
    DatabindingComponent,
    ImageComponent,
    DirectivesComponent,
    ParentComponent,
    ChildComponent,
    NavComponent,
    FooterComponent,
    AngularFormComponent,
    UTDFComponent,
    RTFComponent,
    PageNotFoundComponent,
    PipeComponent,
    MygenderPipe,
    AngularMatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MaterialModule
    
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
