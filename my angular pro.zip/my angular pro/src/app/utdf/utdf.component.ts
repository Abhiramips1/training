import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-utdf',
  templateUrl: './utdf.component.html',
  styleUrls: ['./utdf.component.css']
})
export class UTDFComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
