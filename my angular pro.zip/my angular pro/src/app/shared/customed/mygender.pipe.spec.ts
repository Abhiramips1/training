import { MygenderPipe } from './mygender.pipe';

describe('MygenderPipe', () => {
  it('create an instance', () => {
    const pipe = new MygenderPipe();
    expect(pipe).toBeTruthy();
  });
});
