import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DatabindingComponent } from './databinding/databinding.component';
import { DirectivesComponent } from './directives/directives.component';
import { ParentComponent } from './parent/parent.component';
import { AngularFormComponent } from './angular-form/angular-form.component';
import { UTDFComponent } from './utdf/utdf.component';
import { RTFComponent } from './rtf/rtf.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AngularMatComponent } from './angular-mat/angular-mat.component';

const routes: Routes = [
  {path:"",
  redirectTo:"databinding",
  pathMatch:"full"

  },
  {
    path:"databinding",
    component:DatabindingComponent
  },
{
  path:"directives/:id",
  component:DirectivesComponent
},
{
  path:"directives",
  component:DirectivesComponent
},
{
  path:"curd",loadChildren:()=> import('./curd/curd.module').then(m=>m.CurdModule)
},
{
  path:"angMat",
  component:AngularMatComponent
},

{
  path:"Parent",
component:ParentComponent

},
{
  path:"AngForm",
  component:AngularFormComponent,
  children:[
    { path:"" , component:UTDFComponent},
    { path:"utdf",  component:UTDFComponent},
    { path:"rtf", component:RTFComponent}
  ]

},
{ path:"**",
component:PageNotFoundComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }




