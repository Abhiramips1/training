import React, { Component } from 'react'

 class Conditionalrendering extends Component {
     constructor(){
         super();
         this.state={
             isLogin:true
         }
     }
    render() {
        if(this.state.isLogin){
            return<h2>Hello Admin</h2>
        }
        else{
            return<h2> Hello user</h2>
        }
    }  
//     render(){
//         var msg=""
//         if(this.state.isLogin){
//             msg:"hi user";

//         }
//         else{
//             msg:"hi admin";

//         }
// return msg;


//     }
}

export default Conditionalrendering
