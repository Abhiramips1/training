import React, { Component } from 'react'

 class Color extends Component {
     constructor(){
         super();
         this.state={
             color:[
                 {id:1,name:"red"},
                 {id:2,name:"green"},
                 {id:3,name:"blue"},

             ]
         }
     }
    render() {
        return (
            <div>
                <div calss ="text-primary bg-info display-6"> this is color list</div>
                <ol>
                    {
                       this.state.color.map ((val)=>{
                           return <li>{val.name}</li>
                       })
                    }

                </ol>
            </div>
        )
    }
}

export default Color
