import React from 'react'

function Welcome() {
    return <h2 class="cls2">Welcome to this function</h2>
        
}

export default Welcome
