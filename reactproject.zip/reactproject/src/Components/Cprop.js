import React, { Component } from 'react'

export class Cprop extends Component {
    constructor(props){
        super(props);
        this.state={
            count:1
        }
        // setTimeout(()=> this.setState({count:this.state.count+5}),1000);
    }
    incrementHandler = ()=>{
       this.setState (prevState=>{
           return{
               count:prevState.count+1
           }
       })
    }

    render() {
        var {user,post}=this.props;
        var {count} =this.state;
        return (
            <div>
                <h2>hi welcome {user} !!</h2>
                <p>your post is {post}</p>
                <button type="button" onClick={this.incrementHandler}>click {count} times</button>
                
            </div>
        )
    }
}

export default Cprop
