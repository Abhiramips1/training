import React from 'react'
var Fgreet=(props)=>{
    var {user,post}=props;

    return (
        <div class="cls1">
            <h2>Hi {props.user} Welcome to the class</h2>
            <p> your post is {props.post}</p>
            
        </div>
    )
}

export default Fgreet
