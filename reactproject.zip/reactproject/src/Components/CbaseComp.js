import React, { Component } from 'react'

 class CbaseComp extends Component {
    render() {
        return <h2 class ="cls2">This is class based component</h2>
            
    }
}

export default CbaseComp
