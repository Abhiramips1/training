import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import Welcome from './Components/Welcome';

import CbaseComp from './Components/CbaseComp';
import Fgreet from './Components/Fgreet';
import Cprop from './Components/Cprop';
import Hover from './Components/Hover';
import 'bootstrap/dist/css/bootstrap.min.css';
import Conditionalrendering from './Components/Conditionalrendering';
import Color from './Components/Color';


ReactDOM.render(
  <React.StrictMode>
    <App />
    {/* <Welcome/>
  <CbaseComp></CbaseComp> */}
  <Fgreet user="Ram" post="HR"></Fgreet>
  <hr></hr>
  <Cprop user="Abhirami" post="developer"></Cprop>
  <hr></hr>
  <Hover user="Dev" post="Developer"></Hover>
  <hr></hr>
  <Conditionalrendering></Conditionalrendering>
  <hr></hr>
  <Color></Color>
  
  
    
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
